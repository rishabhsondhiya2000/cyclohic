<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}
?>

<!DOCTYPE html>
<html>
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>UPLOAD IMAGE</title>
        <link rel="stylesheet" href="JqueryUI\jquery-ui.structure.css">
        <link rel="stylesheet" href="JqueryUI\jquery-ui.theme.css">
        <link rel="stylesheet" href="JqueryUI\jquery-ui.css">
          <link rel="stylesheet" href="style.css">
        
    </head>
    <body>

    <div class="heading">
    <img  src="symbol.png" width="80px" height="60px" style="padding-bottom: 1px;" >   
    <h1 >CYCLOHIC</h1>  <hr style="width: 350px; ">
    </div> 

<?php
  if(isset($_POST['upload'])){
      $name=$_FILES['file'];
    
      $file_name=$_FILES['file']['name'];
      $file_Temp=$_FILES['file']['tmp_name'];
      $file_size=$_FILES['file']['size'];
      $file_type=$_FILES['file']['type'];
      $file_error=$_FILES['file']['error'];

      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('png','jpg','jpeg');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                 if($file_size < 10000000){
                     $file_new_name=uniqid('',true).".". $file_act_ext;
                     $file_destination = "uploads/". $file_new_name;

                     move_uploaded_file($file_Temp, $file_destination);
                     
                     $sql="INSERT all_cycle(IMAGE) VALUES ('$file_destination')";
                     if(mysqli_query($conn,$sql)){
                         echo"uploaded";
                     }



                     header("Location: view.php");
                     
                 }
                 else{
                     echo"Your file size is too big";
                 }
            }
            else{
                echo"Error in uploading your file";
            }
      }
      else{
          echo"You cannot upload this type of file.";
      }
  }
?>

<br>
     
    <div style=" text-align:center;">

     <h2 style="color :yellow;">
     ENTER EMAIL ID & PASSWORD !!</h2> <br>
     <form action="" method="POST">
     <input type="email" name="email" placeholder="  ENTER INSTITUTE MAIL ID" 
     style="border-color:red; height:30px; width: 200px; "> <br> <br>
     <input type="password" name="password" placeholder="  ENTER PASSWORD" 
     style="border-color:red; height:30px; width: 200px; "  maxlength="10" minlength="5"> <br>
     <a href="#" style="color : white">forget password?</a> <br> <br>
     
        <button name="done"class="but">DONE</button>
         </form>
    </div>





    <br>
    
    

    
         <?php
        mysqli_close($conn);
        ?>
    
    </body>
    <script src="Jquery\jquery.js" type="text/javascript"></script>
    <script src="JqueryUI\jquery-ui.js" type="text/javascript"></script>
    <script>
        
      

       
    </script>
</html>