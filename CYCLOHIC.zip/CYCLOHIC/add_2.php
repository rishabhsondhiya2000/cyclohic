<?php require("conn.php"); ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ADD DETAILS-CYCLOHIC</title>
  <link rel="stylesheet" href="css/add7.css">
  <link rel="stylesheet" href="css/layout7.css">
  <link rel="shortcut icon" href="favicon.jpg" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&family=Roboto:wght@500&display=swap" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="js/layout2.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
  <div id="mob_nav" class="mobile_nav">
    <h2 class="menu_head">Menu</h2>
    <ul>
      <li><a id="home" href="index.php">Home</a></li>

      <li><a id="add" href="add_1.php">Add Items</a></li>

      <li><a id="view" href="view.php">View Items</a></li>

      <li><a id="contact" href="contact.php">Contact Us</a></li>

      <li><a id="rate" href="rateus.php">Rate Us</a></li>
    </ul>
  </div>
  <div id="nav" class="navigation">
    <div id="main" class="nav-bar">

      <div class="logo">
        <a href="index.php"><img src="images/logo.jpg" alt="LOGO"></a>
      </div>

      <div class="menu">
        <a id="ADD" href="add_1.php">Add Item</a>
        <a id="VIEW" href="view.php">View Item</a>
        <a id="CONTACT" href="contact.php">Contact us</a>
        <a id="RATE" href="rateus.php">Rate us</a>
      </div>
    </div>


    <div class="burger">
      <button onclick="open_nav()">
        <h2>&#9776;</h2>
      </button>
    </div>

  </div>

  <div class="section1">

    <form id="desktop" class="form1" method="POST" enctype="multipart/form-data">
      <h1 class="top">CYCLE DETAILS !!</h1>
      <table>
        <tr>
          <td class="heading">
            <h2>Name :</h2>
          </td>
          <td> <input class="input" style="text-transform: uppercase;" type="text" name="NAME" id="name" required placeholder=" FullName"> </td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Hostel :</h2>
          </td>
          <td> <input class="input" style="text-transform: uppercase;" type="text" name="HOSTEL" id="hostel" required placeholder=" Hostel Name"></td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Mobile No.:</h2>
          </td>
          <td> <input class="input" type="text" name="MOBILE" id="mobile1" maxlength="10" minlength="10" required placeholder=" CONATCT NO."> </td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Cycle's Age :</h2>
          </td>
          <td> <input class="input" type="number" name="AGE" id="age" required placeholder=" Age in Months e.g.( 6 )"></td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Price:</h2>
          </td>
          <td> <input class="input" type="number" name="PRICE" id="price" required placeholder=" Rs. Price e.g.( 2000 )"></td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Image:</h2>
          </td>
          <td><label class="labelForFile submit" for="image">
              <input type="file" name="file" id="image" required></label></td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Set E-Mail id :</h2>
          </td>
          <td> <input class="input" type="email" name="EMAIL" id="email" required placeholder="example.che18@iitbhu.ac.in"></td>
        </tr>

        <tr>
          <td class="heading">
            <h2>Set Password :</h2>
          </td>
          <td> <input class="input" minlength="5" type="password" name="PASSWORD" id="pass" required placeholder=" Min-5 digit"> <button class="show" id="showPass"  type="button" onclick="show()"><i  class="far fa-eye"></i></button> </td>
        </tr>
        <tr>
          <td></td>
          <td> <button name="BUTTON" class="submit" type="sumbit">Sumbit</button></td>
        </tr>
      </table>
    </form>
    <form id="mobile" class="form1" method="POST" enctype="multipart/form-data">
      <h1 class="top">CYCLE DETAILS !!</h1>
      <div class="heading">
        <h2>Name :</h2>
      </div>
      <input class="input" style="text-transform: uppercase;" type="text" name="NAME" id="name1" required placeholder=" FullName">



      <div class="heading">
        <h2>Hostel :</h2>
      </div>
      <input class="input" style="text-transform: uppercase;" type="text" name="HOSTEL" id="hostel1" required placeholder=" Hostel Name">



      <div class="heading">
        <h2>Mobile No.:</h2>
      </div>
      <input class="input" type="text" name="MOBILE" id="mobile2" maxlength="10" minlength="10" required placeholder=" CONATCT NO.">



      <div class="heading">
        <h2>Cycle's Age :</h2>
      </div>
      <input class="input" type="number" name="AGE" id="age1" required placeholder=" Age in Months e.g.( 6 )">

      <div class="heading">
        <h2>Price:</h2>
      </div>
      <input class="input" type="number" name="PRICE" id="price1" required placeholder=" Rs. Price e.g.( 2000 )">


      <div class="heading">
        <h2>Image:</h2>
      </div>
      <label class="labelForFile submit" for="image">
        <i class="fa fa-cloud-upload"></i>
        <input type="file" name="file" id="image1" required></label>



      <div class="heading">
        <h2>Set E-Mail id :</h2>
      </div>
      <input class="input" type="email" name="EMAIL" id="email1" required placeholder="example.che18@iitbhu.ac.in">

      <div class="heading">
        <h2>Set Password :</h2>
      </div>
      <input class="input" minlength="5" type="password" name="PASSWORD" id="pass1" required placeholder=" Min-5 digit"><button class="show" id="showPass1"  type="button" onclick="show()"><i  class="far fa-eye"></i></button>

      <button name="BUTTON" class="submit" type="sumbit">Sumbit</button>

    </form>

    <div class="message">
      <?php
      if (isset($_REQUEST['BUTTON'])) {
        if (($_REQUEST['NAME'] == "") || ($_REQUEST['EMAIL'] == "") || ($_REQUEST['HOSTEL'] == "") ||
          ($_REQUEST['MOBILE'] == "") || ($_REQUEST['AGE'] == "") || ($_REQUEST['PRICE'] == "")
        ) {
          echo "<small>invalid input </small>";
        } else {
          $file_name = $_FILES['file']['name'];
          $file_Temp = $_FILES['file']['tmp_name'];
          $file_size = $_FILES['file']['size'];
          $file_type = $_FILES['file']['type'];
          $file_error = $_FILES['file']['error'];

          $file_ext = explode('.', $file_name);
          $file_act_ext = strtolower(end($file_ext));

          $allowed_ext = array('png', 'jpg', 'jpeg');

          if (in_array($file_act_ext, $allowed_ext)) {
            if ($file_error === 0) {
              if ($file_size < 10000000) {
                $file_new_name = uniqid('', true) . "." . $file_act_ext;
                $file_destination = "uploads/" . $file_new_name;

                move_uploaded_file($file_Temp, $file_destination);
                $name = $_REQUEST['NAME'];
                $hostel = $_REQUEST['HOSTEL'];
                $mobile = $_REQUEST['MOBILE'];
                $age = $_REQUEST['AGE'];
                $price = $_REQUEST['PRICE'];
                $email = $_REQUEST['EMAIL'];
                $password = $_REQUEST['PASSWORD'];
                $new_password = password_hash($password, PASSWORD_BCRYPT);
                $sql = "INSERT INTO all_cycle(EMAIL_ID,PASSWORD,NAME,HOSTEL,MOBILE,CYCLE_AGE,PRICE,IMAGE)
                          VALUES('$email','$new_password','$name', '$hostel','$mobile', '$age', '$price','$file_destination') ";
                if (mysqli_query($conn, $sql)) {
                  echo "<h1 class='top' '>Successfully Sumbitted!!!</h1>";
                } else {
                  echo "<h2 class='top'  '>THIS EMAIL ID IS ALREADY EXIST!!</h2>";
                }
              } else {
                echo "<h2 class='top' '>YOUR IMAGE SIZE IS TOO BIG!</h2>";
              }
            } else {
              echo "<h2 class='top'  '>ERROR IN UPLOADING IMAGE!</h2>";
            }
          } else {
            echo "<h2 class='top'  '>YOU CANNOT UPLAOD THIS IMAGE EXTENSION.!</h2>";
          }
        }
      }
      ?>
    </div>
  </div>



</body>

<script>
  $(document).ready(function() {
    $(".input").keydown(function() {
      $(".input").css("background-color", "rgb(215, 223, 113)");
    });
    $(".input").keyup(function() {
      $(".input").css("background-color", "white");
    });
    var title = document.title;
    var split_title = title.split(" ");
    // console.log(split_title[0]);
    var m_split_title = split_title[0].toLowerCase();
    $("#" + split_title[0]).addClass("active");
    $("#" + m_split_title).addClass("active");
  });

  const show=()=>{
    var pass=document.getElementsByName("PASSWORD");
    var btn=document.getElementsByClassName("show");
    var typo_desktop=pass[0].type;
    var typo_mobile=pass[1].type;
    if(typo_desktop=="password" || typo_mobile=="password"){
      pass[0].type="text";
      pass[1].type="text";
      btn[0].style.backgroundColor="#02024c";
      btn[1].style.backgroundColor="#02024c";
    }
    else{
      pass[0].type="password";
      pass[1].type="password";
      btn[0].style.background="transparent";
      btn[1].style.background="transparent";
    }
  }
</script>

<?php
mysqli_close($conn);
?>

</html>