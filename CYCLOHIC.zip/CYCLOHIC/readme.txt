TODO 
1> forget password 
3> tool tip in alerts