TODO 
1> forget password 
2> feedback email primary key
3> tool tip in alerts