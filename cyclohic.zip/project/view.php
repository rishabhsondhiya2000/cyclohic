

<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}
$sql="SELECT EMAIL_ID,UPPER(NAME),UPPER(HOSTEL),MOBILE,CYCLE_AGE,PRICE
 FROM all_cycle  ORDERBYDESCPRICE ORDER BY ORDERBYDESCPRICE.PRICE ASC";
$result=mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
    <head>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>View Cycles</title>
        <link rel="stylesheet" href="JqueryUI\jquery-ui.structure.css">
        <link rel="stylesheet" href="JqueryUI\jquery-ui.theme.css">
        <link rel="stylesheet" href="JqueryUI\jquery-ui.css">
          <link rel="stylesheet" href="style.css">

        
    </head>
    <body style="background-image: url('yoyo.jpg');
     background-repeat: no-repeat; background-size: 100% 100%; background-attachment: fixed;">

    <div class="heading">
    <img  src="symbol.png" width="80px" height="60px" style="padding-bottom: 1px;" > <hr style="width: 100px;">  
    <h1 >CYCLOHIC</h1>  <hr style="width: 350px; ">
    </div> <br> <br>

    

    
    <div  style="position:relative; columns:5">
      <form action="page1.html" style ="width:500px">
        <button class="but">HOME</button></form>
        
      </div> 
        <br>

        <div style="color: rgb(0, 195, 255);; font-family: Georgia, 'Times New Roman', Times, serif;">
         <?php
        $sql1="SELECT * FROM sold_cycle";
        $res=mysqli_query($conn,$sql1);

        echo "<h2> NUMBER OF CYCLES SOLD : ".mysqli_num_rows($res)." !!</h2>";
     
         ?>
         </div><hr style="width:440px; float:left;">
         
          <br>
          <h1 style="font-family: 'Times New Roman', Times, serif; color:yellow; ">CYCLE'S DETAIL:-</h1>
         <hr style="width:440px; float:left;"> <br> 
          
        
          
        <?php
        if(mysqli_num_rows($result)>0){
          while($row=mysqli_fetch_assoc($result)){ 
          echo"  <div class='mydiv' style='width: 500px'>";
          echo "<h2> Name: ".$row['UPPER(NAME)'] .  "<br>--- Price : Rs.".$row['PRICE'] ."</h2>";
          echo "<p>
          EMAIL ID: ".$row['EMAIL_ID'] ."<br>
          Hostel: ".$row['UPPER(HOSTEL)'] ."<br>
          Mobile: "."+91 ". $row['MOBILE']."<br>
          Cycle's Age: ". $row['CYCLE_AGE']." Months</p></div> <br>
          <div style='position:relative; columns:20; ' >
          <form action='http://localhost/project/delete.php' method='POST'><button type='submit' id='del' 
          style='background-color: rgb(214, 45, 45); color:yellow;cursor: pointer; '>
          DELETE</button></form>
          <form action='http://localhost/project/update.php' method='POST'><button type='submit' id='del' 
            style='background-color: green; color:yellow;cursor: pointer; '>
            UPDATE</button></form>

            </div>";
          
          echo "<br></br>";
          }
          
        }
        else{
          echo "<h2 style='color: red'>No Records are Avaliable at this moment.</h2>";
        }
        ?>
                
      
     <h1 style="color:yellow">-------------------END--------------------</h1> 
     
     
     
    
     <?php
        mysqli_close($conn);
        ?>
    
    </body>
    <script src="Jquery\jquery.js" type="text/javascript"></script>
    <script src="JqueryUI\jquery-ui.js" type="text/javascript"></script>
    <script>
        
        $(".mydiv").accordion({
           collapsible:true,
           event:"click",
           animate:300,
           active:"1",
           heightStyle:false,
           
       })
       $(document).ready(function(){
         $(".mydiv").slideUp(0.01);
         $(".mydiv").slideDown(1500);
       })

       
    </script>
</html>