<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}

$per_page=1;
$record=mysqli_num_rows(mysqli_query($conn, "select * from all_cycle"));
$pagi=ceil($record/$per_page);
$start=0;
$cur_page=1;
if(isset($_GET['start'])){
  $start=$_GET['start'];
  $cur_page=$start;
  $start--;
}


$sql="SELECT EMAIL_ID,UPPER(NAME),UPPER(HOSTEL),MOBILE,CYCLE_AGE,PRICE,IMAGE
 FROM all_cycle  ORDERBYDESCPRICE ORDER BY ORDERBYDESCPRICE.PRICE ASC
";
$result=mysqli_query($conn, $sql);


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYCLOHIC-VIEW CYCLES</title>
    <link rel="stylesheet" href="css/view.css">
    <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">

    
        
    </head>
    <body >

    <div class="nav-bar">

    <div class="logo">
      <a href="index.html"><img src="images/logo.jpg" alt="LOGO"></a>
    </div>
        <form action="http://localhost/project/add_1.php">
        <button type="sumbit" class="but"> Add Item </button>
        </form>

        <form action="http://localhost/project/view.php">
        <button type="sumbit" class="but">View Item </button>
        </form>

        <form action="contact_1.html">
        <button  type="sumbit" class="but">Contact us</button>
        </form>

        <form action="http://localhost/project/rateus.php">
        <button  type="sumbit" class="but">Rate us</button>
        </form>

    </div>

        <div class="sold_no" >
         <?php
        $sql1="SELECT * FROM sold_cycle";
        $res=mysqli_query($conn,$sql1);
        echo "<h2> NUMBER OF CYCLES SOLD : ".mysqli_num_rows($res)." !!</h2>";
         ?>
         </div>
         
         <hr style="width:440px; float:left;"> <br>
         
          <div class="search">
              <input  type="text" id="myinput" name="search" placeholder="&#x1F50D; Search by Name" onkeyup="search()">
          </div>
          
          <h1 style=" margin-left: 10px; font-family: 'Times New Roman', Times, serif; color:rgb(244 246 7); ">CYCLE'S DETAIL:-</h1>
         <hr style="width:440px; float:left;"> <br> 
          
         <div class="content">
             <div id="first" class="first">
        <?php
        if(mysqli_num_rows($result)>0){
          while($row=mysqli_fetch_assoc($result)){ 
          echo" <div class='div'> <div  class='mydiv' style='width: 490px'>";
          echo "<h2> Name:<span> ".$row['UPPER(NAME)'] . "</span><br>--- Price : Rs.".$row['PRICE'] ."</h2>";
          echo "<p><strong>
          EMAIL ID: ".$row['EMAIL_ID'] ."<br>
          Hostel: ".$row['UPPER(HOSTEL)'] ."<br>
          Mobile: "."+91 ". $row['MOBILE']."<br>
          Cycle's Age: ". $row['CYCLE_AGE']." Months <br>
          Image: <a href='". $row['IMAGE']."' target='_block'>view image</a>  </strong></p></div><br> 
          <div class='edit_btn' >
          <form action='http://localhost/project/delete.php' method='POST'>  
            <input type='hidden' name='email' value='".$row['EMAIL_ID']."' readonly >        
            <button type='submit' class='btn' style='background-color: rgb(214, 45, 45); color:yellow;cursor: pointer; '>
          DELETE</button></form>
             <form action='http://localhost/project/update.php' method='POST'>
              <input type='hidden' name='email' value='".$row['EMAIL_ID']."' readonly >
            <button type='submit' class='btn' style='background-color: green; color:yellow;cursor: pointer; '>
            UPDATE</button></form>

            </div> ";
          
          echo "<br></br> </div>";
          }
          
        }
        else{
          echo "<h2 style='color: red'>No Records are Avaliable at this moment.</h2>";
        }
        for($i=1;$i<=$pagi;$i++){
          echo'<a id="page"'.$i.' class="page" href="?start='.$i.'">'.$i.'</a>';
        }

        ?> 
        <script>
          
        </script>
          </div>

          <div class="second">

          </div>

    
        </div>

    
     <?php
        mysqli_close($conn);
        ?>
    
    </body>
    <script src="Jquery\jquery.js" type="text/javascript"></script>
    <script src="JqueryUI\jquery-ui.js" type="text/javascript"></script>
    <script>
        
        $(".mydiv").accordion({
           collapsible:true,
           event:"click",
           animate:300,
           active:"1",
           heightStyle:false,
           
       })
       $(document).ready(function(){
         $(".mydiv").slideUp(0.01);
         $(".mydiv").slideDown(1500);
         
  
       })

       function search(){
            let filter=document.getElementById('myinput').value.toUpperCase();

            let div=document.getElementsByClassName('div');

            for(var i=0;i<div.length;i++){
              let name=div[i].getElementsByTagName('span');
              if(name[1].textContent.indexOf(filter) > -1){
                  div[i].style.display='';
              }
              else{
                div[i].style.display='none';
              }
            }

         }

       
    </script>
</html>