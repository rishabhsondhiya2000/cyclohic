<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}
?>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYCLOHIC</title>
    <link rel="stylesheet" href="css/rateus.css">
    <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">
   
</head>

<body>
    <div class="nav-bar">

        <div class="logo">
            <a href="index.html"><img src="images/logo.jpg" alt="LOGO"></a>
        </div>
        <form action="http://localhost/project/add_1.php">
            <button  type="sumbit" class="but"> Add Item </button>
        </form>

        <form action="http://localhost/project/view.php">
            <button  type="sumbit" class="but">View Item </button>
        </form>

        <form action="contact_1.html">
            <button  type="sumbit" class="but">Contact us</button>
        </form>

        <form action="http://localhost/project/rateus.php">
            <button type="sumbit" class="but">Rate us</button>
        </form>

    </div>
     
    <div  class="container">
          <div class="left">
            <form action="" method="post">
            <h1 style="color:rgb(200, 255, 0)" >GIVE US YOUR FEEDBACK:-</h1>
            <hr style="width:68%;">
            <table>
                <tr>
                <td><h2 class='heading' >EMAIL ID :</h2></td>
                <td> <input class="input height"  type="email"  name="email"  required placeholder="Email ID"> </td>
                </tr>

                <tr>
                <td><h2 class='heading'>FEEDBACK :</h2></td>
                <td> <textarea cols="31" rows="10" class="input"  type="text"  name="feedback"  required placeholder="FEEDBACK"></textarea> </td>
                </tr>

                <tr>
                <td></td>
                <td> <input class="submit"  type="submit"  name="submit"  > </td>
                </tr>
        </table>
            </form>
            <?php
            if(isset($_REQUEST['submit'])){
                $email=$_REQUEST['email'];
                $feedback=$_REQUEST['feedback'];
                $timestamp=time();
                $insert="INSERT INTO feedback(emailid,feedback,timestamp) values('$email','$feedback','$timestamp')";
                mysqli_query($conn,$insert);
                echo"<br><br><h1 style='color:rgb(200, 255, 0); ' >Thank You for your feedback !!!</h1>";
            }
            
            
            ?>


          </div>
          <div class="right">
          <h1 style='color:rgb(200, 255, 0); ' >FEEDBACKS:-</h1>

          <?php
            $show="select * from feedback order by timestamp desc LIMIT 2 ";
            $res=mysqli_query($conn,$show);
            while($row=mysqli_fetch_assoc($res)){
                 echo"
                 <div class='feedback'>
                 <h2> &rightarrow;".$row['emailid']." </h2>
                 <p>&rightarrow;".$row['feedback']."</p>
                 </div>
                 ";
            }
          
          ?>
            
          <div class='feedback'>
               <h2> &rightarrow; rishabhsondhiya@2000gmail.com</h2>
               <p>&rightarrow;Awesome website!! great work</p>
          </div>

          
            
        
          </div>

        </div>
    



</body>
   


</script>

</html>