<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}

$emailid=$_POST['email'];
?>


<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CYCLOHIC</title>
  <link rel="stylesheet" href="css/update.css">
  <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
</head>

<body>
  <div class="nav-bar">

  <div class="logo">
      <a href="index.html"><img src="images/logo.jpg" alt="LOGO"></a>
    </div>
    <form action="http://localhost/project/add_1.php">
      <button  type="sumbit" class="but"> Add Item </button>
    </form>

    <form action="http://localhost/project/view.php">
      <button  type="sumbit" class="but">View Item </button>
    </form>

    <form action="contact_1.html">
      <button  type="sumbit" class="but">Contact us</button>
    </form>
    
    <form action="http://localhost/project/rateus.php">
        <button  type="sumbit" class="but">Rate us</button>
        </form>
   

  </div>
     

    <div id="box" class="box" >
           <div class="left">
     <h2 style="color :yellow;">
     ENTER EMAIL ID & PASSWORD !!</h2> <br>
     <form action="" method="POST">
     <input type="email" name="email"  value='<?php echo $emailid;?>' readonly> <br> <br>
     <input type="password" name="password" placeholder="  ENTER PASSWORD" 
       maxlength="10" minlength="5"> <br>
     <a href="" style="color : white">forget password?</a> <br> <br>
     
        <button name="done"class="btn">DONE</button>
         </form>
    </div>   
       <div class="right">
    <?php
                    
                  if(isset($_REQUEST["done"])){
                  $sql1="SELECT * FROM all_cycle WHERE EMAIL_ID='{$_REQUEST['email']}' AND PASSWORD='{$_REQUEST['password']}'";
                  $result=mysqli_query($conn, $sql1);
                  $row=mysqli_fetch_assoc($result);
                    if(mysqli_num_rows($result)>0){?>
                          <script>
                            let left=document.getElementsByClassName('left');
                            left[0].style.display='none'
                          </script>
                         
                          <?php
                          echo"<h1 style='color :yellow;padding-left: 73px;'>CYCLE DETAILS:</h1><hr style='width:400px'>";
                          echo"<form action='' class='form1' style='text-align: center;' method='POST' >";
                          echo"
                          <table>
                            <tr>
                            <td><h2 style='color :white;'>NAME:</h2></td> 
                            <td><input required name='name' type='text' value=' $row[NAME]'> </td>
                            </tr>" ;
                          
                          echo"
                          <tr>
                          <td><h2 style='color :white;'>HOSTEL:</h2></td> 
                          <td><input required name='hostel' type='text'  value=' $row[HOSTEL]'> </td>
                          </tr>" ;

                          echo"
                          <tr>
                          <td><h2 style='color :white;'>MOBILE NO:</h2></td> 
                          <td><input required name='mobile' type='text'  maxlength='10' minlength='10' value=' $row[MOBILE]'> </td>
                          </tr>" ;
                          echo"
                          <tr>
                          <td><h2 style='color :white;'>CYCLE AGE:</h2></td> 
                          <td><input name='age' type='number'  required value=$row[CYCLE_AGE]> </td>
                          </tr>" ;
                          echo"
                          <tr>
                          <td><h2 style='color :white;'>PRICE: </h2></td>
                          <td><input required name='price' type='number'  value=$row[PRICE]> </td>
                          </tr>" ;
                          echo"
                          <tr>
                          <td><h2 style='color :white; '>EMAIL ID:</h2></td> 
                          <td><input required name='email' type='email' value=' $row[EMAIL_ID]' readonly> </td>
                          </tr>" ;
                          echo"
                          <tr>
                          <td><h2 style='color :white;'>PASSWORD:</h2></td> 
                          <td><input name='password' type='password'  value='$row[PASSWORD]' readonly> </td>
                          </tr>" ;
                          echo"
                          <tr>
                          <td></td>
                          <td><button  name='update' class='btn' type='sumbit'>UPDATE</button></td>
                          </tr> </table>";
                          echo"</form>";    
                    }
                  
                    else{
                      echo "<h2 style='color :yellow;text-align:center;'>WRONG PASSWORD!!</h2><hr style='width:400px'> ";
                    } 
     
                   }
                    ?>   

                    <?php
                      
                      if(isset($_REQUEST["update"])){
                        
                        $pass=$_REQUEST['password'];
                        $nam=$_REQUEST['name'];
                        $email=$_REQUEST["email"];
                        $hostel=$_REQUEST["hostel"];
                        $mob=$_REQUEST["mobile"];
                        $age=$_REQUEST["age"];
                        $price=$_REQUEST["price"];
                        $sql2="UPDATE all_cycle
                               SET NAME='$nam',HOSTEL='$hostel',MOBILE='$mob',
                               CYCLE_AGE='$age',PRICE='$price' WHERE EMAIL_ID='$email'";
                        if(mysqli_query($conn,$sql2)){
                          echo"<h1 style='color :yellow; text-align: center;'>DATA UPDATED SUCCESSFULLY!!</h1> <hr style='width: 600px'>";
                          
                        }
                        else{
                          echo"<h1 style='color :yellow; text-align: center;'> NOT UPDATED!! </h1><hr style='width: 300px'>";
                        }
  
                      }
                    ?>
                    </div>
                    </div>
                    
       
    
     
    

    </body>
    <script src="Jquery/jquery.js" type="text/javascript"></script>
    <script src="JqueryUI/jquery-ui.js" type="text/javascript"></script>
    <script>
        $(document).ready(function(){
            
        })


    </script>
</html>