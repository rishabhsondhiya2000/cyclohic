<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}
?>


<html>
    <head>
        <title>UPDATE</title>
        <link rel="stylesheet" href="JqueryUI/jquery-ui.structure.css">
        <link rel="stylesheet" href="JqueryUI/jquery-ui.theme.css">
        <link rel="stylesheet" href="JqueryUI/jquery-ui.css">
        <link rel="stylesheet" href="style.css">

        
        
        
    </head>
    <body style="background-image: url('yoyo.jpg')
    ; background-repeat: no-repeat; background-size: 100% 100%; background-attachment: fixed;">

<div class="heading">
    <img  src="symbol.png" width="80px" height="60px" style="padding-bottom: 1px;" > <hr style="width: 100px;">  
    <h1 >CYCLOHIC</h1>  <hr style="width: 350px; ">
  </div>
          <br>
          <form action="http://localhost/project/view.php">
            <button class="but">BACK</button>
             </form> <br>
     
    <div  style=" text-align:center;">

     <h2 style="color :yellow;">
     ENTER EMAIL ID & PASSWORD !!</h2> <br>
     <form action="" method="POST">
     <input type="email" name="email" placeholder="  ENTER INSTITUTE MAIL ID" 
     style="border-color:red; height:30px; width: 200px; "> <br> <br>
     <input type="password" name="password" placeholder="  ENTER PASSWORD" 
     style="border-color:red; height:30px; width: 200px; "  maxlength="10" minlength="5"> <br>
     <a href="" style="color : white">forget password?</a> <br> <br>
     
        <button name="done"class="but">DONE</button>
         </form>
    </div>   

    <?php
                    
                  if(isset($_REQUEST["done"])){
                  $sql1="SELECT * FROM all_cycle WHERE EMAIL_ID='{$_REQUEST['email']}' AND PASSWORD='{$_REQUEST['password']}'";
                  $result=mysqli_query($conn, $sql1);
                  $row=mysqli_fetch_assoc($result);
                    if(mysqli_num_rows($result)>0){
                          
                          echo"<h1 style='color :yellow; text-align:center;'>CYCLE DETAILS:</h1><hr style='width:400px'>";
                          echo"<form action='' style='text-align: center;' method='POST' >";
                          echo"<h2 style='color :white;'>NAME: 
                          <input required name='name' type='text' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);' value=' $row[NAME]'> </h2>" ;
                          
                          echo"<h2 style='color :white;'>HOSTEL: 
                          <input required name='hostel' type='text' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);' value=' $row[HOSTEL]'> </h2>" ;
                          echo"<h2 style='color :white;'>MOBILE NO: 
                          <input required name='mobile' type='text' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);' maxlength='10' minlength='10' value=' $row[MOBILE]'> </h2>" ;
                          echo"<h2 style='color :white;'>CYCLE AGE: 
                          <input name='age' type='number' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);' required value=$row[CYCLE_AGE]> </h2>" ;
                          echo"<h2 style='color :white;'>PRICE: 
                          <input required name='price' type='number' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);' value=$row[PRICE]> </h2>" ;
                          echo"<h2 style='color :white; '>EMAIL ID: 
                          <input required name='email' type='email' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);'value=' $row[EMAIL_ID]' readonly> </h2>" ;
                          echo"<h2 style='color :white;'>PASSWORD: 
                          <input name='password' type='password' style='width: 200px; height: 30px; border-radius: 20px; 
                          border-color: rgb(5, 5, 5);' value='$row[PASSWORD]' readonly> </h2>" ;
                          echo"<button id='btn1' name='update' class='but' type='sumbit'>UPDATE</button>";
                            

                          
                          
                          echo"</form>";    
                    }
                  
                    else{
                      echo "<h2 style='color :white;text-align:center;'>WRONG PASSWORD!!</h2><hr style='width:400px'> ";
                    } 
     
                   }
                    ?>   

                    <?php
                      
                      if(isset($_REQUEST["update"])){
                        
                        $pass=$_REQUEST['password'];
                        $nam=$_REQUEST['name'];
                        $email=$_REQUEST["email"];
                        $hostel=$_REQUEST["hostel"];
                        $mob=$_REQUEST["mobile"];
                        $age=$_REQUEST["age"];
                        $price=$_REQUEST["price"];
                        $sql2="UPDATE all_cycle
                               SET NAME='$nam',HOSTEL='$hostel',MOBILE='$mob',
                               CYCLE_AGE='$age',PRICE='$price' WHERE EMAIL_ID='$email'";
                        if(mysqli_query($conn,$sql2)){
                          echo"<h1 style='color :white; text-align: center;'>DATA UPDATED SUCCESSFULLY!!</h1> <hr style='width: 600px'>";
                          
                        }
                        else{
                          echo"<h1 style='color :white; text-align: center;'> NOT UPDATED!! </h1><hr style='width: 300px'>";
                        }
  
                      }
                    ?>
                    
       
    
     
    

    </body>
    <script src="Jquery/jquery.js" type="text/javascript"></script>
    <script src="JqueryUI/jquery-ui.js" type="text/javascript"></script>
    <script>
        $(document).ready(function(){
            
        })


    </script>
</html>