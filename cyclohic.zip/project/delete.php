
<?php

$conn=mysqli_connect("localhost","root","","my_db");
if(!$conn){
  die("connection failed");
}
$emailid=$_POST['email'];

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CYCLOHIC</title>
  <link rel="stylesheet" href="css/delete.css">
  <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">
</head>

<body>
  <div class="nav-bar">

  <div class="logo">
      <a href="index.html"><img src="images/logo.jpg" alt="LOGO"></a>
    </div>
    <form action="http://localhost/project/add_1.php">
      <button id="btn1" type="sumbit" class="but"> Add Item </button>
    </form>

    <form action="http://localhost/project/view.php">
      <button id="btn2" type="sumbit" class="but">View Item </button>
    </form>

    <form action="contact_1.html">
      <button id="btn3" type="sumbit" class="but">Contact us</button>
    </form>
    <form action="http://localhost/project/rateus.php">
        <button  type="sumbit" class="but">Rate us</button>
        </form>

  </div>
    

     
    <div class="box" >
      <div class="left">

            <h2 style="color :yellow;">
            ENTER EMAIL ID & PASSWORD !!</h2> <br>
            <form action="" method="POST">
            <input type="email" name="email"   value='<?php echo $emailid;?>' readonly > <br> <br>
            <input type="password" name="password" placeholder="  ENTER PASSWORD"  required
              maxlength="10" minlength="5"> <br>
            <a href="http://localhost/project/delete.php" style="color : white">forget password?</a> <br> <br>
            
                <button name="done" class="btn">DONE</button>
                </form>
        </div>

        <div class="right">
        <?php
          if(isset($_REQUEST["done"])){
            
            $password=$_REQUEST['password'];
          $sql1="SELECT * FROM all_cycle WHERE EMAIL_ID='$emailid'";
          $result=mysqli_query($conn, $sql1);
          $count=mysqli_num_rows($result);
          if($count){
            $email_password=mysqli_fetch_assoc($result);
            $db_pass=$email_password['PASSWORD'];
            if(password_verify($password, $db_pass)){

              echo "LOGIN";
             $sql2="INSERT sold_cycle SELECT EMAIL_ID,NAME,HOSTEL,PRICE,CYCLE_AGE,MOBILE  FROM all_cycle WHERE all_cycle.EMAIL_ID='$emailid'";
              if(mysqli_query($conn, $sql2)){
                 $sql3="DELETE FROM all_cycle WHERE EMAIL_ID='$emailid'";
                 if(mysqli_query($conn,$sql3)){
                  header("Location: view.php?sucessfullydeleted");
                 }
                 else{
                  echo "<h2 style='text-align:center;'>UNABLE TO DELETE!!</h2><hr style='width:600px'> ";
                 }
              
              }
             else{
               echo "<h2 style='text-align:center;'>UNABLE TO DELETE!!</h2><hr style='width:600px'> ";
             } 

            }
            else{
              echo "<h2 style='text-align:center;'>INCORRECT PASSWORD!!</h2><hr style='width:600px'> ";
            }
          }
          
          }

?>

        </div>
    </div>
    <br>
      <?php
        mysqli_close($conn);
        ?>
    
    </body>
    <script src="Jquery\jquery.js" type="text/javascript"></script>
    <script src="JqueryUI\jquery-ui.js" type="text/javascript"></script>
    <script>
        
      

       
    </script>
</html>