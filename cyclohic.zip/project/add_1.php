<?php

  $conn=mysqli_connect("localhost","root","","my_db");
  if(!$conn){
    die("connection failed");
  }
  ?>
  
  <!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYCLOHIC-ADD DETAILS</title>
    <link rel="stylesheet" href="css/add.css">
    <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">
        
    </head>
    <body >

    <div class="nav-bar">

    <div class="logo">
      <a href="index.html"><img src="images/logo.jpg" alt="LOGO"></a>
    </div>
        <form action="http://localhost/project/add_1.php">
        <button id="btn1" type="sumbit" class="but"> Add Item </button>
        </form>

        <form action="http://localhost/project/view.php">
        <button id="btn2" type="sumbit" class="but">View Item </button>
        </form>

        <form action="contact_1.html">
        <button id="btn3" type="sumbit" class="but">Contact us</button>
        </form>
        
        <form action="http://localhost/project/rateus.php">
      <button  type="sumbit" class="but">Rate us</button>
      </form>
       

    </div>
      
    <div class="section1">
        
    <form class="form1" method="POST" enctype="multipart/form-data">
    <h1 class="top"   >CYCLE DETAILS !!</h1>
    <table>
        <tr>
        <td class="heading"><h2 >Name :</h2></td>
        <td> <input class="input" style="text-transform: uppercase;" type="text"  name="NAME" id="name"  required placeholder=" FullName"> </td>
        </tr>

        <tr>  
        <td class="heading"><h2 >Hostel :</h2></td>
        <td> <input class="input" style="text-transform: uppercase;" type="text" name="HOSTEL" id="hostel"  required placeholder=" Hostel Name"></td>
        </tr>

        <tr>
        <td class="heading"><h2 >Mobile No.:</h2></td>
        <td> <input class="input" type="text" name="MOBILE"  id="mobile"   maxlength="10" minlength="10" required placeholder=" CONATCT NO."> </td>
        </tr>

        <tr>
        <td class="heading"><h2 >Cycle's Age :</h2></td>
        <td> <input class="input" type="number" name="AGE" id="age"  required placeholder=" Age in Months e.g.( 6 )"></td>
       </tr>

       <tr>
       <td class="heading"><h2 >Price:</h2></td>
       <td> <input class="input" type="number" name="PRICE" id="price" required placeholder=" Rs. Price e.g.( 2000 )"></td>
       </tr>

       <tr>
       <td class="heading"><h2 >Image:</h2></td>
       <td> <input style=" color:white;" type="file" name="file" id="image" required ></td>
       </tr>

       <tr>
      <td class="heading"> <h2 >Set E-Mail id :</h2></td>
      <td> <input class="input" type="email" name="EMAIL" id="email" required placeholder="example.che18@iitbhu.ac.in"></td>
      </tr>

       <tr>
       <td class="heading">  <h2 >Set Password :</h2></td>
       <td> <input class="input"  minlength="5" type="password" name="PASSWORD" id="pass" 
         required placeholder=" Min-5 digit"></td>
      </tr>
            <tr>
                <td></td>
               <td> <button name="BUTTON" class="submit" type="sumbit">Sumbit</button></td>
           </tr>
    </table>
    </form>

    <div class="message">
    <?php
      if(isset($_REQUEST['BUTTON'])){
        if(($_REQUEST['NAME'] == "") || ($_REQUEST['EMAIL'] == "") ||($_REQUEST['HOSTEL'] == "") ||
        ($_REQUEST['MOBILE'] == "") ||($_REQUEST['AGE'] == "") ||($_REQUEST['PRICE'] == "") ){
            echo "<small>invalid input </small>";
        } 
        else{
          $file_name=$_FILES['file']['name'];
          $file_Temp=$_FILES['file']['tmp_name'];
          $file_size=$_FILES['file']['size'];
          $file_type=$_FILES['file']['type'];
          $file_error=$_FILES['file']['error'];
    
          $file_ext=explode('.' , $file_name);
          $file_act_ext=strtolower(end($file_ext));
    
          $allowed_ext=array('png','jpg','jpeg');
    
          if(in_array( $file_act_ext , $allowed_ext)){
                if($file_error=== 0){
                     if($file_size < 10000000){
                         $file_new_name=uniqid('',true).".". $file_act_ext;
                         $file_destination = "uploads/". $file_new_name;
    
                          move_uploaded_file($file_Temp, $file_destination);
                          $name=$_REQUEST['NAME'];
                          $hostel=$_REQUEST['HOSTEL'];
                          $mobile=$_REQUEST['MOBILE'];
                          $age=$_REQUEST['AGE'];
                          $price=$_REQUEST['PRICE'];
                          $email=$_REQUEST['EMAIL'];
                          $password=$_REQUEST['PASSWORD'];
                          $new_password=password_hash($password,PASSWORD_BCRYPT);
                          $sql="INSERT INTO all_cycle(EMAIL_ID,PASSWORD,NAME,HOSTEL,MOBILE,CYCLE_AGE,PRICE,IMAGE)
                          VALUES('$email','$new_password','$name', '$hostel','$mobile', '$age', '$price','$file_destination') ";
                          if(mysqli_query($conn,$sql)){
                              echo "<h1 style='color:yellow; text-align: center;font-family: Georgia, 'Times New Roman', Times, serif;
                              text-underline-position: below;'>Successfully Sumbitted!!! <hr style='width:600px'></h1>";
                              header('Location:view.php');
                          }
                          else{
                              echo "<h2 style='color:yellow; text-align:center; '>THIS EMAIL ID IS ALREADY EXIST!!
                              </h2><hr style='width:400px'>";
                          }
                         
                     }
                     else{
                      echo "<h2 style='color:yellow; text-align:center; '>YOUR IMAGE SIZE IS TOO BIG!
                      </h2><hr style='width:400px'>";
                         
                     }
                }
                else{
                    echo "<h2 style='color:yellow; text-align:center; '>ERROR IN UPLOADING IMAGE!
                     </h2><hr style='width:400px'>";
                    
                }
          }
          else{
            echo "<h2 style='color:yellow; text-align:center; '>YOU CANNOT UPLAOD THIS IMAGE EXT.! 
            </h2><hr style='width:400px'>";
              
          }
        }
            
    }
?>
    </div>
    </div>
    
    
        
    </body>
    <script src="Jquery/jquery.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js" type="text/javascript"></script>
    <script>
        $("#form1").slideDown(0.1);
            $("#form1").slideUp(0.1);
            $("#form1").slideDown(2000);
         $(document).ready(function(){  
                        $(".input").keydown(function(){  
                            $(".input").css("background-color", "rgb(215, 223, 113)");  
                        });  
                        $(".input").keyup(function(){  
                            $(".input").css("background-color", "white");  
                        });  
                });  
     
        </script>
        
        <?php
        mysqli_close($conn);
        ?>
</html>
