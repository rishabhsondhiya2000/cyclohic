<?php

  $conn=mysqli_connect("localhost","root","","my_db");
  if(!$conn){
    die("connection failed");
  }
  echo "hello"; 
  ?>
  
  <!DOCTYPE html>
<html>
    <head>
        <title>ADD CYCLE</title>
        <link rel="stylesheet" href="JqueryUI/jquery-ui.structure.css">
        <link rel="stylesheet" href="JqueryUI/jquery-ui.theme.css">
        <link rel="stylesheet" href="JqueryUI/jquery-ui.css">
        <link rel="stylesheet" href="style.css">
        
    </head>
    <body style="background-image: url('yoyo.jpg')
    ; background-repeat: no-repeat; background-size: 100% 100%; background-attachment: fixed;">

<div class="heading">
    <img  src="symbol.png" width="80px" height="60px" style="padding-bottom: 1px;" > <hr style="width: 100px;">  
    <h1 >CYCLOHIC</h1>  <hr style="width: 350px; ">
  </div> <br><div id="div1" style="columns:8">
      <form action="page1.html" style ="width:500px">
        <button class="but">HOME</button></form>
      </div> 
      
      <?php
      if(isset($_REQUEST['BUTTON'])){
        if(($_REQUEST['NAME'] == "") || ($_REQUEST['EMAIL'] == "") ||($_REQUEST['HOSTEL'] == "") ||
        ($_REQUEST['MOBILE'] == "") ||($_REQUEST['AGE'] == "") ||($_REQUEST['PRICE'] == "") ){
            echo "<small>invalid input </small>";
        } 
        else{
            $name=$_REQUEST['NAME'];
            $hostel=$_REQUEST['HOSTEL'];
            $mobile=$_REQUEST['MOBILE'];
            $age=$_REQUEST['AGE'];
            $price=$_REQUEST['PRICE'];
            $email=$_REQUEST['EMAIL'];
            $password=$_REQUEST['PASSWORD'];
            $sql="INSERT INTO all_cycle(EMAIL_ID,PASSWORD,NAME,HOSTEL,MOBILE,CYCLE_AGE,PRICE)
            VALUES('$email','$password','$name', '$hostel','$mobile', '$age', '$price') ";
            if(mysqli_query($conn,$sql)){
                echo "<h1 style='color:white; text-align: center;font-family: Georgia, 'Times New Roman', Times, serif;
                text-underline-position: below;'>Successfully Sumbitted!!! <hr style='width:600px'></h1>";
            }
            else{
                echo "<h2 style='color :white; text-align:center; '>THIS EMAIL ID IS ALREADY EXIST!!
                </h2><hr style='width:400px'>";
            }
        }
            
    }
?>
  
        
    <form id="form1" action=""  onsubmit="return validate(); "  style="text-align: center;color: white;" method="POST" >
    <h1 style="color:yellow" >CYCLE DETAILS !!</h1> <hr style="width:350px">
    <h2 >Name: <input type="text" name="NAME" id="name" style="width: 200px; height: 30px; border-radius: 20px; 
    border-color: rgb(5, 5, 5); "  placeholder=" FullName"> 
    <label id="lbl1"  style="color: red; visibility: hidden;" >Invalid</label></h2>
       
    <h2 >Hostel      : <input type="text" name="HOSTEL" id="hostel" style="width: 200px; height: 30px; border-radius: 20px; 
        border-color: rgb(5, 5, 5);"  placeholder=" Hostel Name">
        <label id="lbl3"  style="color: red; visibility: hidden;" >Invalid</label></h2>
    <h2 >Mobile No.: <input type="text" name="MOBILE"  id="mobile" style="width: 200px; height: 30px; border-radius: 20px; 
        border-color: rgb(5, 5, 5);" maxlength="10" minlength="10"  placeholder=" Molile no.">
        <label id="lbl4"  style="color: red; visibility: hidden;" >Invalid</label></h2>
    <h2 >Cycle's Age : <input type="number" name="AGE" id="age" style="width: 200px; height: 30px; border-radius: 20px; 
        border-color: rgb(5, 5, 5);"  placeholder=" Age in Months e.g.( 6 )">
        <label id="lbl5"  style="color: red; visibility: hidden;" >Invalid</label></h2>     
    <h2 >Price: <input type="number" name="PRICE" id="price" style="width: 200px; height: 30px; border-radius: 20px; 
        border-color: rgb(5, 5, 5);" placeholder=" Rs. Price e.g.( 2000 )">
        <label id="lbl6"  style="color: red; visibility: hidden;" >Invalid</label></h2> 
        
        <h2 >Set E-Mail id: <input type="email" name="EMAIL" id="email" style="width: 200px; height: 30px; border-radius: 20px; 
        border-color: rgb(5, 5, 5);" placeholder="example.che18@iitbhu.ac.in">
        <label id="lbl7"  style="color: red; visibility: hidden;" >Invalid</label></h2>

        <h2 >Set Password: <input  maxlength="10" minlength="5" type="password" name="PASSWORD" id="pass" style="width: 200px; height: 30px; border-radius: 20px; 
        border-color: rgb(5, 5, 5);" placeholder=" Min-5 digit & Max-10 digit">
        <label id="lbl8"  style="color: red; visibility: hidden;" >Invalid</label></h2> 
        
        <button id="btn1" name="BUTTON" class="but" type="sumbit">Sumbit</button>
    </form>
    
    
        
    </body>
    <script src="Jquery/jquery.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js" type="text/javascript"></script>
    <script>
        $("#form1").slideDown(0.1);
            $("#form1").slideUp(0.1);
            $("#form1").slideDown(2000);
         $(document).ready(function(){  
                        $("input").keydown(function(){  
                            $("input").css("background-color", "rgb(215, 223, 113)");  
                        });  
                        $("input").keyup(function(){  
                            $("input").css("background-color", "white");  
                        });  
                });  
                
        
            
  
            function validate(){
                var Name= document.getElementById("name");
                var Hostel= document.getElementById("hostel");
                var Mobile= document.getElementById("mobile");
                var Age= document.getElementById("age");
                var Price= document.getElementById("price");
                var Email= document.getElementById("email");
                var Pass= document.getElementById("pass");
                var img= document.getElementById("FILE");
                if(Name.value.trim()==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl1").style.visibility="visible";
                    return false;
                }
                
                else if(Hostel.value==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl3").style.visibility="visible";
                    return false;
                }
                else if(Mobile.value==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl4").style.visibility="visible";
                    return false;
                }
                else if(Age.value==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl5").style.visibility="visible";
                    return false;
                }
                else if(Price.value==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl6").style.visibility="visible";
                    return false;
                }
                else if(email.value==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl7").style.visibility="visible";
                    return false;
                }
                else if(Pass.value==""){
                    alert("No blank value allowed!!");
                    document.getElementById("lbl8").style.visibility="visible";
                    return false;
                }
                else{
                    return true;
                }   
            }

            
                
            
        </script>
        
        <?php
        mysqli_close($conn);
        ?>
</html>
