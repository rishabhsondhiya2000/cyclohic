<?php
  $conn=mysqli_connect('localhost','root','','test');

?>

  <form action="" method="post" enctype="multipart/form-data">
  <input type="text" name="name" >
    <input type="file" name="file" required> <span style="color:green;" id="span"></span>
    <button type="submit" name="btn">UPLOAD</button>
</form>

<?php
  if(isset($_POST['btn'])){
      
      $name=$_REQUEST['name'];
      $file_name=$_FILES['file']['name'];
      $file_Temp=$_FILES['file']['tmp_name'];
      $file_size=$_FILES['file']['size'];
      $file_type=$_FILES['file']['type'];
      $file_error=$_FILES['file']['error'];

      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('png','jpg','jpeg');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                 if($file_size < 10000000){
                     $file_new_name=uniqid('',true).".". $file_act_ext;
                     $file_destination = "uploads/". $file_new_name;

                     move_uploaded_file($file_Temp, $file_destination);
                      $name=$_REQUEST['NAME'];
                      $hostel=$_REQUEST['HOSTEL'];
                      $mobile=$_REQUEST['MOBILE'];
                      $age=$_REQUEST['AGE'];
                      $price=$_REQUEST['PRICE'];
                      $email=$_REQUEST['EMAIL'];
                      $password=$_REQUEST['PASSWORD'];
                      $new_password=password_hash($password,PASSWORD_BCRYPT);
                      $sql="INSERT INTO all_cycle(EMAIL_ID,PASSWORD,NAME,HOSTEL,MOBILE,CYCLE_AGE,PRICE,IMAGE)
                      VALUES('$email','$new_password','$name', '$hostel','$mobile', '$age', '$price','$file_destination') ";
                      if(mysqli_query($conn,$sql)){
                          echo "<h1 style='color:yellow; text-align: center;font-family: Georgia, 'Times New Roman', Times, serif;
                          text-underline-position: below;'>Successfully Sumbitted!!! <hr style='width:600px'></h1>";
                          header('Location:view.php');
                      }
                      else{
                          echo "<h2 style='color:yellow; text-align:center; '>THIS EMAIL ID IS ALREADY EXIST!!
                          </h2><hr style='width:400px'>";
                      }
                     
                 }
                 else{
                  echo "<h2 style='color:yellow; text-align:center; '>YOUR IMAGE SIZE IS TOO BIG!
                  </h2><hr style='width:400px'>";
                     
                 }
            }
            else{
                echo "<h2 style='color:yellow; text-align:center; '>ERROR IN UPLOADING IMAGE!
                 </h2><hr style='width:400px'>";
                
            }
      }
      else{
        echo "<h2 style='color:yellow; text-align:center; '>YOU CANNOT UPLAOD THIS IMAGE EXT.! 
        </h2><hr style='width:400px'>";
          
      }
  }
?>